#ifndef MULT_H
#define MULT_H

#include <stdint.h>

int64_t mult(int64_t, int64_t);

#endif
